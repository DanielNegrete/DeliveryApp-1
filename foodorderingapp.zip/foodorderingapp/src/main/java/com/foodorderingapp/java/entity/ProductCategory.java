package com.foodorderingapp.java.entity;

public enum ProductCategory {
	
	VEG, NONVEG
}
