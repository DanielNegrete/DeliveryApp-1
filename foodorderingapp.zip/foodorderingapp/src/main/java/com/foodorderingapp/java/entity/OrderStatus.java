package com.foodorderingapp.java.entity;

public enum OrderStatus {
	
	PLACED, DELIVERED, FAILED
}
