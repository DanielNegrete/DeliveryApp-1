package com.foodorderingapp.java.exception;

public class ViolationErrorResponse extends ErrorResponse{

	public ViolationErrorResponse(String message, String statusCode) {
		super(message, statusCode);
		// TODO Auto-generated constructor stub
	}
}
